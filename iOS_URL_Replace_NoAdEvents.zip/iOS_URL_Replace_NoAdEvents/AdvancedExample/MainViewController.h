@import GoogleInteractiveMediaAds;
@import UIKit;

@interface MainViewController : UIViewController

// Handle to TableView.
@property(nonatomic, weak) IBOutlet UITableView *tableView;

@end
